# @mkhamis72/self-auth

Shared sign-in for the owner's apps. Each app gets its own Better Auth instance, with users and sessions in
the app's own Postgres, schema `self_auth`. Apps only see this package's API, which takes `companyId` and
`email`. The login key and real address stay internal.

## Install

There is no registry yet. Install from a tarball or a folder:

```sh
npm pack                                  # in packages/self-auth, gives mkhamis72-self-auth-0.1.0.tgz
npm i ../path/to/mkhamis72-self-auth-0.1.0.tgz
```

The package is marked `"private": true` until it is published. When the GitHub remote exists, replace that
line with `publishConfig: { registry: "https://npm.pkg.github.com" }`.

## Set up the database

Apply `sql/0001_self_auth.sql` with the app's own migration runner. Self-Auth never runs DDL at runtime.

## Configure

```ts
import { createSelfAuth } from '@mkhamis72/self-auth';

const auth = await createSelfAuth({
  databaseUrl: process.env.DATABASE_URL!,
  secret: process.env.SELF_AUTH_SECRET!,      // at least 32 characters
  appName: 'Implant Course',                  // shown in authenticator apps
  dbToken: { privateJwk, kid, ttlSeconds: 300 }, // ttlSeconds optional, default 300
  email: { send: async (msg) => { /* msg.to, msg.kind, msg.url, msg.companyId */ } },
  links: {
    resetPassword: (companyId, token) => `https://app.example/reset?t=${token}`,
    acceptInvite: (companyId, token) => `https://app.example/invite?t=${token}`,
  },
  sessionTtlSeconds: 604800,                  // optional, default 7 days
  onError: (err, { op }) => { /* optional: log swallowed errors; never receives tokens or URLs */ },
});
```

- `companyId` must be a DNS-label-like string: lowercase letters, digits and hyphens, up to 63 characters,
  starting with a letter or digit.
- Emails go only to the user's real address. If it is missing, the call throws `missing_real_email`.
- Reset and invite links are sent only through `email`. They are never returned to the caller.

## API

Every call that touches an existing user or session takes `companyId`, and a user or session from another
company is treated as not found.

- `signIn({ companyId, email, password })`, `getSession(token, companyId)`, `signOut(token)`,
  `revokeSessions(companyId, userId)`
- `changePassword(token, companyId, currentPassword, newPassword)`: self-service change. Returns `true` on
  success and `false` for a wrong current password or while locked out; wrong guesses count toward the sign-in
  lockout. Ends every other session of the user and keeps this one. Throws `no_session` if the session isn't
  valid for the company and `weak_password` outside 8 to 128 characters
- `issueDbToken(session)`, `jwks()`
- `totp.hasTotp(userId)`, `totp.startEnroll(token, companyId)`, `totp.confirmEnroll(token, companyId, code)`,
  `totp.verify(token, companyId, code)`, `totp.remove(token, companyId)`
- `requestPasswordReset({ companyId, email, reportSendErrors? })`, `resetPassword({ token, newPassword })` (returns
  `{ userId, companyId }` or `null`; check the company), `acceptInvite({ token, password })` (same result)
- `admin.createUser({ companyId, email, password })`, `admin.invite({ companyId, email })`,
  `admin.setDisabled(companyId, userId, disabled)`, `admin.updateEmail(companyId, userId, email)`,
  `admin.deleteUser(companyId, userId)`, `admin.listUsers(companyId)`,
  `admin.setPassword(companyId, userId, newPassword)` (admin-set password; revokes all sessions, clears the
  lockout; `weak_password` outside 8 to 128 characters, `user_not_found` for another company),
  `admin.resetTotp(companyId, userId)` (deletes the TOTP factor and revokes all sessions; `user_not_found`
  if the user isn't in that company)
- `importSupabaseUser({ companyId, userId, email, passwordHash, totpSecret, createdAt })`, a one-time import
  that keeps the user's id
- `close()` ends the database pool
- Errors are `SelfAuthError`, with the reason in `.code`
- Passwords must be 8 to 128 characters; otherwise `weak_password` (createUser) or `null` (reset, invite)

## Password reset form

`requestPasswordReset` resolves the same way for known and unknown addresses. If the email adapter fails for a
known user, the error goes to `onError(err, { op: 'requestPasswordReset' })` and the call still resolves.
Admin actions that must tell the admin whether the mail went out pass `reportSendErrors: true`: a failed send then
also rejects with `send_failed` (no cause, URL or token attached). Never pass it from a public form. The
send is awaited, so response time can still differ between known and unknown addresses. The app must
rate-limit the reset form.

## Connect Supabase (PostgREST)

So that Supabase accepts the tokens from `issueDbToken`, import the public keys from `jwks()` into Supabase:
Dashboard → Project Settings → JWT Keys → import as a standby key. Then the database accepts tokens signed
with the matching `kid`.
